const { validationResult } = require("express-validator");

const validateMiddleware = (req, res, next) => {

  const errors = validationResult(req);

  // Check validation errors
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: "Validation Failed",
      errors: errors.array(),
    });
  }

  next();
};

module.exports = validateMiddleware;