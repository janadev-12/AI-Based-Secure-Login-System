const loadEnv = require("./config/env");
loadEnv();

const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");

const connectDB = require("./config/db");
const sessionMiddleware = require("./security/session");
const csrfProtection = require("./security/csrfProtection");
const limiter = require("./middleware/rateLimiter");
const errorMiddleware = require("./middleware/errorMiddleware");
const authRoutes = require("./routes/authRoutes");

connectDB();

const app = express();

app.use(express.json());
app.use(cors());
app.use(helmet());
app.use(morgan("dev"));
app.use(limiter);
app.use(sessionMiddleware);
// app.use(csrfProtection);

app.get("/", (req, res) => {
  res.status(200).json({
    message: "🔥 AI Secure Login System Running",
  });
});

app.use("/api/auth", authRoutes);

app.use(errorMiddleware);

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});